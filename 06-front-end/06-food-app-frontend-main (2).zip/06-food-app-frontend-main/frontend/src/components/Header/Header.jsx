 
import './header.css'

const Header = () => {
  return (
    <div className='header'>
    <div className="header-contents">
        <h2>Friends Foods  your food here</h2>
        <p>choose from the menu items given below here . they are made all by satya and vishu bhai for punnu gunda and satyaansh bro</p>
    <button>View Menu</button>
    </div>
      
    </div>
  )
}

export default Header
